package com.infy.license;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LicenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
