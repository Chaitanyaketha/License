package com.infy.license.model;

public enum LicensePurpose {
    INTERNAL, EXTERNAL, COMMERCIAL,PRODUCTION
}